//
//  Invoice.swift
//  Factura
//
//  Created by DAMII on 2/06/19.
//  Copyright © 2019 Cibertec. All rights reserved.
//

import Foundation

class Invoice  {
    var numero : String
    var fecha : String
    var ruc : String
    var nombrecli: String
    var total: String
    
    init(numero: String,fecha: String,ruc: String,nombrecli: String,total: String) {
        self.numero = numero
        self.fecha = fecha
        self.ruc = ruc
        self.nombrecli = nombrecli
        self.total = total
        
    }
}

//
//  InvoiceTableViewController.swift
//  Factura
//
//  Created by DAMII on 2/06/19.
//  Copyright © 2019 Cibertec. All rights reserved.
//

import UIKit


protocol DelegateInvoiceTableViewController {
    func cancelPressed()
    func donePressed(invoice: Invoice, position: Int?)
    
}


class InvoiceTableViewController: UITableViewController {
    
    var delegate: DelegateInvoiceTableViewController?
    var invoice: Invoice?
    var position: Int?
    
    @IBOutlet weak var inputNro: UITextField!
    
    @IBOutlet weak var inputFecha: UITextField!
    
    @IBOutlet weak var inputRuc: UITextField!
    
    @IBOutlet weak var inputNombreCli: UITextField!
    
    @IBOutlet weak var inputTotal: UITextField!
    
    @IBAction func cancelPressed(_ sender: UIBarButtonItem) {
        
        delegate?.cancelPressed()
        
        
    }
    
    @IBAction func donePressed(_ sender: UIBarButtonItem) {
        let numero = self.inputNro.text!
        let fecha = self.inputFecha.text!
        let ruc = self.inputRuc.text!
        let nombrecli = self.inputNombreCli.text!
        let total = self.inputTotal.text!
        
        if invoice == nil{
            invoice = Invoice(numero: numero, fecha: fecha,ruc: ruc,nombrecli:nombrecli, total: total )
        }
        else{
            invoice?.numero = numero
            invoice?.fecha = fecha
            invoice?.ruc = ruc
            invoice?.nombrecli = nombrecli
            invoice?.total = total
        }
        
       delegate?.donePressed(invoice: invoice!, position: position)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Cargar los datos si se esta modificando la factura
        if invoice != nil{
            
            inputNro.text = invoice?.numero
            inputNombreCli.text = invoice?.nombrecli
            inputFecha.text = invoice?.fecha
            inputRuc.text = invoice?.ruc
            inputTotal.text = invoice?.total
            
        }
        
    }

   

}

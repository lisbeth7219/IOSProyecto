//
//  BuscarViewController.swift
//  Factura
//
//  Created by DAMII on 23/06/19.
//  Copyright © 2019 Cibertec. All rights reserved.
//

import UIKit
import WebKit

class BuscarViewController: UIViewController {

    
    @IBOutlet weak var inputNro: UITextField!
    
    @IBOutlet weak var labelLink: UILabel!
    
    @IBOutlet weak var inputLink: UILabel!
    
    @IBOutlet weak var buttonEnlace: UIButton!
    
    @IBOutlet weak var viewWeb: WKWebView!
    
    @IBAction func showInvoice(_ sender: UIButton) {
        
        let url = URL(string: inputLink.text!)
        viewWeb.load(URLRequest(url: url!))
    }
    
    
    
    @IBAction func searchFactura(_ sender: UIBarButtonItem) {
        
        loadItems()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    func loadItems(){
        
        let todosEndpoint: String = "https://api.nubefact.com/api/v1/825d40cd-c201-4a6d-8214-d8a51f1499cc"
        
        let token = "f84c26c437084de386e5a7f61d30eaa119f95168e0844053aea8a63575bc2968"
        //let todosURL = URL(string: todosEndpoint)
        
        let numeroFactura = inputNro.text!
        
        guard let todosURL = URL(string: todosEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        var todosUrlRequest = URLRequest(url: todosURL)
        todosUrlRequest.httpMethod = "POST"
        
        todosUrlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        todosUrlRequest.setValue(token, forHTTPHeaderField: "Authorization")
        
        let newTodo: [String: Any] = [
            "operacion": "consultar_comprobante",
            "tipo_de_comprobante": 1,
            "serie": "FFF1",
            "numero": numeroFactura
        ]
        let jsonTodo: Data
        do {
            jsonTodo = try JSONSerialization.data(withJSONObject: newTodo, options: [])
            todosUrlRequest.httpBody = jsonTodo
        } catch {
            print("Error: cannot create JSON from todo")
            return
        }
        
        
        let session = URLSession.shared
        
       
        let task = session.dataTask(with: todosUrlRequest) {
            (data, response, error) in
            guard error == nil else {
                print("error calling POST on /todos/1")
                print(error!)
                return
            }
            
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            
            // parse the result as JSON, since that's what the API provides
            do {
                guard let receivedTodo = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any]
                    
                    else {
                    
                        print("Could not get JSON from responseData as dictionary")
                        return
                }
                // print("The todo is: " + receivedTodo.description)
                
                guard let todoID = receivedTodo["enlace"] as? String else {
                    print("Could not get todoID as String from JSON")
                    return
                }
                print("The Numero is: \(todoID)")
                
                
                DispatchQueue.main.async {
                   // self.tableView.reloadData()
                     self.inputLink.text! = todoID
                    self.buttonEnlace.titleLabel?.text! = todoID
                }
            } catch  {
                print("error parsing response from POST on /todos")
                return
            }
        }
        task.resume()
        
        
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  TableViewCell.swift
//  Factura
//
//  Created by DAMII on 2/06/19.
//  Copyright © 2019 Cibertec. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var labelNumero: UILabel!
    
    
    @IBOutlet weak var labelNombreCli: UILabel!
    
    
    @IBOutlet weak var labelFecha: UILabel!
    
    
    @IBOutlet weak var labelMonto: UILabel!
    
    func initCell(invoice: Invoice) {
        self.labelNumero.text = invoice.numero
        self.labelNombreCli.text = invoice.nombrecli
        self.labelFecha.text = invoice.fecha
        self.labelMonto.text = invoice.total
    }
    
}
